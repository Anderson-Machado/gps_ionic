import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { Exemplo3Page } from './exemplo3.page';

const routes: Routes = [
  {
    path: '',
    component: Exemplo3Page
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [Exemplo3Page]
})
export class Exemplo3PageModule {}
